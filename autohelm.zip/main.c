/*********************************************************************************
*                                                                                
*   File Name:   main.c                                                                
*                                                                                
*   Content:     Contains main loop for demo code                                                                
**********************************************************************************                                                                               
*   Copyright (c) 2002 Mitsubishi Electric and Electronics USA, Inc.             *    
*   All rights reserved                                                          *
**********************************************************************************
*   The software supplied by Mitsubishi Electric and Electronics USA, Inc.       *
*   is intended and supplied for use on Mitsubishi Electric  products.           *
*   This software is owned by Mitsubishi Electric and Electronics USA, Inc.      *
*   or Mitsubishi Electric Corporation and is protected under applicable         *
*   copyright laws. All rights are reserved.                                     *                                                                                *
*   THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS, IMPLIED   *
*   OR STATUTORY, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF             *
*   MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. *
*   MITSUBISHI ELECTRIC AND ELECTRONICS USA, INC. AND MITSUBISHI ELECTRIC        *
*   CORPORATION RESERVE THE RIGHT, WITHOUT NOTICE, TO MAKE CHANGES TO THIS       *
*   SOFTWARE. NEITHER MITSUBISHI ELECTRIC AND ELECTRONICS USA, INC. NOR          *
*   MITSUBISHI ELECTRIC CORPORATION SHALL, IN ANY CIRCUMSTANCES, BE LIABLE       *
*   FOR SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER  *
*   ARISING OUT OF THE USE OR APPLICATION OF THIS SOFTWARE.                      *
*                                                                                *
*================================================================================*
*   $Log: main.c,v $
*   Revision 1.2  2002-06-07 14:00:18-04  bembry
*   Fixed flicker problem.  Chang Temp conversion equation fixes problem at "0" crossover point.
*
*================================================================================*/
#include <stdlib.h>
#include "10sk.h"		/* SFR register definition */
#include "rtc.h"        /* real time clock function. */
#include "delayTimer.h" /* delay timer for compass I2C readings*/
#include "compass.h"  //analog compass andrew mcknight
#include "MagAcc.h"		//digital compass revised andrew mcknight

void display_task(void);
void mode_task(void);
void display_welcome_message(void);
void display_time(char ln);
void AD_sample_task(void);
void AD_compass_task(void);
//#pragma INTERRUPT ad_intr_handler
void ad_intr_handler(void);
void toStr(char strNum[9],int value,int menuNum);
int changeVariable(int menuSelected,int changeValue);
int getCompassReading(int avg);
void shaftDelayToggle();

unsigned char ad_flag;
unsigned char sys_mode;
enum SYSTEM_MODES{RUNNING=0,MENUCHANGE,VALUECHANGE};
char cur_hour, cur_min, cur_sec, last_sec;
int paused, selected_menu;
int allowedVariation,moveDelay,moveShaft;
long int lastSec;
char key;
const char menu[4][9] = {
{"HEADING "},
{"DELAY   "},
{"TOLERANC"},
{" PAUSED "}};

const char num[15] = {'0','1','2','3','4','5','6','7','8','9',':','F','C',' ','.'};
const char deg_S[8] = {0x08,0x14,0x08,0x00,0x00,0x00,0x00,0x00};
unsigned char clock_mode_change;    // set according to mode of clock.              
unsigned char temp_mess_dis_timer;  // temp display timer. 
unsigned char current_sys_mode;     // return to mode after time out. 
unsigned char temp_display_mode;    // allows setting of temp display mode. 
unsigned char clock_fault_reset;    
unsigned char init_osc_det; 
unsigned char clock_mode_charnge; 
unsigned int ad_value, avg_ad_value;                 //ad values.
unsigned int ad_compass;  //for the compass analog2digital value
double avg_ad_compass;	//for the compass average value
int setOffSet;    //for initilizing compass offset
float temperature;
// added object from compass.h
compass heading={0,0,0,"    ","   "};
//end of created object from compass.h

/*****************************************************************************
Name:		main
Parameters:	None
Returns:	None 
Description: Initializes the system and then responds to user actions.
*****************************************************************************/
void main()
{
	allowedVariation=6;//degrees + or minus of the heading on start
	moveDelay=1;//wait one second before moving again 100/100's of a second
	lastSec=0;//set the shaftDelayToggle to zero
	moveShaft=1;//set the shaft toggle to start moving
  //menu prep*******************************************
  paused=1;
  selected_menu=0;
  sys_mode =  RUNNING;
  //end of menu prep**********************************************
	//heading.strHeading[3]=0x07;
	//heading.strHeading[7]=0x07;//this is the degree charactor
    init_BSP();     // Intialize Board Support Package.
    disp_ctrlw(0x78); // write CGRAM address pointer 
    for (key=0; key <8; key++)   // degree symbole is 0x08 hex.  
        disp_dataw(deg_S[key]);  // Write degree symbole to LCD's CGRAM area.       
    cur_hour = 0; cur_min = 0; cur_sec = 0; last_sec = 0;   // Intialize clock variables
	init_Timer();
	set_time(cur_hour,cur_min,cur_sec);
    /*** enable 32K clcok for real time clock.****/
    prc0 = 1;       // Enable writes to clock control register.
    cm03 = 1;       // Xcin, Xcout high drive mode  
    cm04 = 1;       // Enable Xcin, Xcout ports 
    cm2 = 0x03;      // Enable OSC STOPPED detection 
    prc0 = 0;       // Disable writes to clock control register. 
	/*** setup input for shaft extended all ,shaft in all ****/
	pd4_2=0;//shaft in all input
	pd4_3=0;// shaft out all input
	/*** setup output move shaft in, move shaft out ****/
	pd4_0=1;//move shaft in
	pd4_1=1;//move shaft out               
	/** setup led ouput ***/
	pd4_4=1;
	/****   Initialize Digital compass reading **************/
	//HMC6352_Init();
	//pu02=0; //pull up control register for p1_0->p1_3 set to 
	initMagAcc();
	/****   End of Initialize Digital compass reading **************/
    init_osc_det = 0;
    clock_fault_reset = 0;
    temp_mess_dis_timer = 0;
    clock_mode_charnge = 0;
	//intro screen
	display(0,"AUTOHELM");
	display(1," < > OK ");
	
    //addTask(display_task, 30, 1);
    addTask(mode_task, 20, 2);
    //addTask(AD_sample_task, 10/*5*/, 3);//changed to 100 milli sec? for digital compass read
    Run_RR_Scheduler();
}
/**********************************************************************************
Name:		  followHeading
Parameters:
Returns:
Description:  sets the lines to high and low to move the motor in order to follow the heading
**************************************************************************/

void followHeading(){
	int compDiff=0;
	int accrossN=0;
	char temp0Str[9]="\0";
	char temp1Str[9]="\0";
	set_compass(&heading,getCompassReading(1));
	//display(0,heading.strHeading);
	compDiff=abs((heading.current-heading.desired));
	if(compDiff>180){
		compDiff=abs(compDiff-360);
		accrossN=1;
	}
	if(compDiff>allowedVariation){
		toStr(temp0Str,heading.current,0);
		display(0,temp0Str);
		if(moveDelay!=0){
			shaftDelayToggle();
		}
		else{
			moveShaft=1;
		}
		if((heading.current>heading.desired && accrossN==0) || (accrossN==1 && heading.current<heading.desired)){
			if(!p4_2){
				p4_1=0;//set move out to off
				if(moveShaft){
					p4_0=1;//set move in to on
				}
				else{
					p4_0=0;//set move in to off
				}
				p4_4=1;//turn on led
				toStr(temp1Str,heading.desired,9);
				display(1,temp1Str);
			}
		}
		else{
			if(!p4_3){
				p4_0=0;//set move in to off
				if(moveShaft){
					p4_1=1;//set move out to on
				}
				else{
					p4_1=0;//set move out to off
				}
				p4_4=1;//turn on led
				toStr(temp1Str,heading.desired,8);
				display(1,temp1Str);
			}
		}
	}
	else{
		p4_1=0;//set move out to off
		p4_0=0;//set move in to off
		p4_4=0;//turn off led
		moveShaft=1;//setup so that when boat not on compass heading the shaft starts moving without delay
		toStr(temp0Str,heading.current,0);
		display(0,temp0Str);
		get_time(&cur_hour, &cur_min, &cur_sec);
		display_time(1);
	}
	if(p4_2){
		p4_0=0;
		display(1,"SHAFT IN");
	}
	else if(p4_3){
		p4_1=0;
		display(1,"SHAFTOUT");
	}
}


/*****************************************************************************
Name:         mode_task  
Parameters:                     
Returns:        
Description:  Process key inputs and changes mode and data.    
*****************************************************************************/
void mode_task(void)
{	
	//KEY_A IS UP
	//KEY_B IS DOWN
	//KEY_C IS OK
	int i=0;
	int selected_value=0;
	char tempStr[9]="";
    int testHeading=0;
	key = dequeue_key();
	
	// testHeading=get_digital_heading();
	// toStr(tempStr,testHeading,0);
	// display(0,tempStr);
	
	
	
    switch(sys_mode){
		case RUNNING:
			if(paused){
				if(key==KEY_C){
					paused=0;
					set_desired(&heading,getCompassReading(0));
				}
				else if(key==KEY_A||key==KEY_B){
					sys_mode=MENUCHANGE;
					selected_menu=0;
				  	display(0,menu[0]);
					display(1," < > OK ");
				}
				else{
					toStr(tempStr,heading.desired,0);
					display(0,tempStr);
					display(1,menu[3]);//display paused
				}
			}
			else if(key==KEY_A || key == KEY_B || key == KEY_C){
					paused=1;//true
					toStr(tempStr,heading.desired,0);
					display(0,tempStr);
					display(1,menu[3]);//display paused
			}
			else
				followHeading();
		break;
		case MENUCHANGE:
			switch(key){
				case KEY_A:
					selected_menu++;
					display(1," < > OK ");
				break;
				case KEY_B:
					selected_menu--;
					display(1," < > OK ");
				break;
				case KEY_C:
					sys_mode=VALUECHANGE;
					selected_value=changeVariable(selected_menu,0);
					toStr(tempStr,selected_value,selected_menu);
					display(1,tempStr);					
				break;
				
			}
		  if(selected_menu<0)
			selected_menu=2;
		  else if(selected_menu>2)
			selected_menu=0;
		display(0,menu[selected_menu]);
		break;
		case VALUECHANGE:
			switch(key){
				case KEY_A:
					selected_value=changeVariable(selected_menu,-1);
					toStr(tempStr,selected_value,selected_menu);
					display(0,menu[selected_menu]);
					display(1,tempStr);					
				break;
				case KEY_B:
					selected_value=changeVariable(selected_menu,1);
					toStr(tempStr,selected_value,selected_menu);
					display(0,menu[selected_menu]);
					display(1,tempStr);					

				break;
				case KEY_C:
					sys_mode=RUNNING;
					paused=0;
					if(selected_menu!=0){
						set_desired(&heading,getCompassReading(0));
					}
				break;
			}
		break;
    }
}

void toStr(char strNum[9],int value,int menuNum){
	strNum[0]=' ';
	strNum[1]=' ';
	if(menuNum==8){
		strNum[2]='>';
	}
	else{
		strNum[2]=' ';
	}
	strNum[3]=(value/100)+48;
	strNum[4]=(((value%100)/10))+48;
	strNum[5]=(value%10)+48;
	if(menuNum!=1 ){
		strNum[6]=0x07;
	}
	else{
		strNum[6]=' ';
	}
	if(menuNum==9){
		strNum[7]='<';
	}
	else{
		strNum[7]=' ';
	}
	strNum[8]='\0';
}
int changeVariable(int menuSelected,int changeValue){
	switch(menuSelected){
		case 0:
			heading.desired+=changeValue;
			set_desired(&heading,heading.desired);
			return heading.desired;
		break;
		case 1:
			moveDelay+=changeValue;
			if(moveDelay<0){
				moveDelay=0;
			}
			return moveDelay;
		break;
		case 2:
			allowedVariation+=changeValue;
			if(allowedVariation<0){
				allowedVariation=0;
			}
			return allowedVariation;
		break;

	}
	return 0;
}
/*****************************************************************************
Name:           shaftDelayToggle      
Parameters:     none                     
Returns:        none
Description:    this helps create an intermitent shaft movement by waiting the 
					aloted moveDelay time with the shaft moving and then
					spending the same moveDelay time without moving the shaft
*****************************************************************************/
void shaftDelayToggle(){
	long int currSec=get_Secs();
	if(((lastSec+moveDelay)-currSec)<=0){
		lastSec=currSec;
		if(moveShaft){
			moveShaft=0;
		}
		else{
			moveShaft=1;
		}
	}
}


/*****************************************************************************
Name:           display_time      
Parameters:     ln --> LCD line number.                     
Returns:        
Description:    display current time on line 0 of 1 of LCD.    

*****************************************************************************/
void display_time(char ln)
{
	static unsigned char result;
	if(ln == 0)
		result = LCD_HOME_L1;
	else 
		result = LCD_HOME_L2; 
	disp_ctrlw(result);      // home to line ln
	result = cur_hour / 10;  disp_dataw(num[result]);
	result = cur_hour - (result * 10); disp_dataw(num[result]);
	disp_dataw(num[10]);    // print ":"
	result = cur_min / 10; disp_dataw(num[result]);
	result = cur_min - (result * 10);  disp_dataw(num[result]);
	disp_dataw(num[10]);    // print ":"
	result = cur_sec / 10;  disp_dataw(num[result]);
	result = cur_sec - (result * 10);  disp_dataw(num[result]);
}
/*****************************************************************************
Name:         AD_sample_task 
Parameters:                     
Returns:        
Description:  gets the heading from I2c protocol handler and sets the compass
				direction

*****************************************************************************/
void AD_sample_task(void)
{
	//static int countCC=2;
	double degrees=0;
	//if(--countCC==0){
	//	degrees=sample();
	//	countCC=2;
	//}
	if(degrees)
		set_compass(&heading,degrees/10);
	// else
		// bad_strCurrent(&heading); 
	//wait_ticks(2000);
}
/*****************************************************************************
Name:        ad_intr_handler   
Parameters:                     
Returns:        
Description:  AD interrupt handler.   

*****************************************************************************/
void ad_intr_handler(void)
{
	ad_compass = ad +1;
    adst = 0;
}
/*****************************************************************************
Name:        getCompassReading 
Parameters:        none             
Returns:        a newly read compass heading from the digital compass
Description:  returns a newly read compass heading from the digital compass   

*****************************************************************************/
int getCompassReading(int avg){
	int oldValue=heading.current;
	int newDigitHeading=get_digital_heading();
	newDigitHeading-=180;
    if (newDigitHeading < 0) newDigitHeading += 360;
	if(avg){
		newDigitHeading=(unsigned int)((oldValue * 11.0/24.0) + ((newDigitHeading * 13)/24.0));//smooth readings
	}
return newDigitHeading;
}