/*
u=kp*(e+Td*diff(e)+Td*int(e))
y0=analog input 1;
r0=ref=set point or reference;
T=sample time;
qd=diff constant=Kp*Td/T; //Td:diff time
qi=integral cosntant=Kp*T/Ti; //Ti:Integration time
Kp=prop gain;
*/

float pid (float r0, float y0) 
{
e0=r0-y0;
D=qd*(e0-e1);
if (((u>umin)|(e>0))&((u<umax)|(e<0))) //antiwindup integral
I=I+qi*(r0-y0);

u=Kp*e0+D+I;//pid control signal
if (u>umax) u=umax; //antiwindup PID
if (u<umin) u=umin;

e1=e0; //save old values
y1=y0;
}